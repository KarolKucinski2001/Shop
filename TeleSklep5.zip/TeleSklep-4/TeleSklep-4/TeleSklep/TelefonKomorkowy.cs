﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleSklep
{
    public enum EnumLadowanieBezp { Tak, Nie };
    public class TelefonKomorkowy : Telefon
    {
        int wyswietlacz;
        string system;
        int aparat;
        EnumLadowanieBezp ladowamnie;

        public int Wyswietlacz { get => wyswietlacz; set => wyswietlacz = value; }
        public string System { get => system; set => system = value; }
        public int Aparat { get => aparat; set => aparat = value; }
        public EnumLadowanieBezp Ladowamnie { get => ladowamnie; set => ladowamnie = value; }
        static TelefonKomorkowy() { }

        public TelefonKomorkowy(int wyswietlacz, string system, int aparat, EnumLadowanieBezp ladowamnie, string modelTelefonu, EnumStan stan, string kolor, decimal waga, int pojemnoscBaterii, double cena,
           EnumMarka markaTelefonu, EnumPamiecRam pamiecRam) : base(modelTelefonu, stan, kolor, waga, pojemnoscBaterii, cena,
                markaTelefonu, pamiecRam)
        {
            this.wyswietlacz = wyswietlacz;
            this.system = system;
            this.aparat = aparat;
            this.ladowamnie = ladowamnie;



        }

        //public TelefonKomorkowy(EnumStan stan, string kolor, decimal waga, int wyswietlacz, double cena,
        //    string system, int aparat, int pamiec, string procesor, EnumLadowanieBezp ladowamnie,
        //    EnumMarka markaTelefonu): base(cena, stan, kolor, waga, wyswietlacz, pamiec, markaTelefonu, abc)
        //{
        //    this.wyswietlacz = wyswietlacz;
        //    this.system = system;
        //    this.aparat = aparat;
        //    this.procesor = procesor;
        //    this.ladowamnie = ladowamnie;
        //}





        public override string ToString()
        {
            return base.ToString() + $"Wyświetlacz: {Wyswietlacz}, System: {System}, Aparat: {Aparat}, Ładowanie: {Ladowamnie}";
        }

    }
}

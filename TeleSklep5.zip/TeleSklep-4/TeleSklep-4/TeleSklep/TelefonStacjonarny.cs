﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleSklep
{
    public enum EnumObslugaSMS { Tak, Nie };
    public enum EnumGlosnoMowiacy { Tak, Nie };
    public class TelefonStacjonarny : Telefon
    {
        EnumObslugaSMS obsluga;
        EnumGlosnoMowiacy glosnoMowiacy;


        public EnumObslugaSMS Obsluga { get => obsluga; set => obsluga = value; }
        public EnumGlosnoMowiacy GlosnoMowiacy { get => glosnoMowiacy; set => glosnoMowiacy = value; }
        static TelefonStacjonarny() { }

        public TelefonStacjonarny(EnumObslugaSMS obsluga, EnumGlosnoMowiacy glosnoMowiacy, string modelTelefonu, EnumStan stan, string kolor, decimal waga, int pojemnoscBaterii, double cena,
              EnumMarka markaTelefonu, EnumPamiecRam pamiecRam) : base(modelTelefonu, stan, kolor, waga, pojemnoscBaterii, cena,
                markaTelefonu, pamiecRam)
        {
            this.obsluga = obsluga;
            this.glosnoMowiacy = glosnoMowiacy;
        }


        public override string ToString()
        {
            return base.ToString() + $"Obsługa SMS: {Obsluga}, Głośnomówiący: {GlosnoMowiacy}";
        }


    }
}

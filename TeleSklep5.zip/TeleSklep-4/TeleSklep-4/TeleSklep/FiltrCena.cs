﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleSklep
{
    public class FiltrCena : IFunkcjeFiltrujace
    {
        private int maxCena;

        public int MaxCena
        {
            get => maxCena;
            set
            {
                if(value<=0)
                {
                    throw new Exception(); //stworzyc  klas wyjatek dla błedu 
                }
                maxCena = value;
            }
        }
        public FiltrCena(int cena)
        {
            this.MaxCena = cena;
        }

        public List<Telefon> Filtruj(List<Telefon> listaWejsciowa) // usuwamy te ktore nie spełniaja wymagan 
        {
            List<Telefon> wynik = new List<Telefon>();
            foreach (Telefon telefon in listaWejsciowa)
            {
                if (telefon.Cena <= MaxCena) // jezeli jest mniejsze bądź równe, to dodajemy 
                {
                    wynik.Add(telefon);
                }
            }
            return wynik;
        }
        //public List<Telefon> Filtruj()
        //{
        //    List<TelefonyKomorkowe> listaKategorii = new List<TelefonyKomorkowe>();
        //    foreach (var p in wszystkieTelefony)
        //    {
        //        if (p.PamiecRam == pamiecRam && p.Cena < cena && p.MarkaTelefonu == markaTelefonu)
        //        {
        //            listaKategorii.Add(p);
        //        }
        //    }
        //    return listaKategorii;
        //}


    }
}

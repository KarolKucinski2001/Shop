﻿using System.Collections.ObjectModel;
using System.Windows;

namespace TeleSklep
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        Telefon telefon;
        public MainWindow()
        {
           // ten kod wykonuje sie przy uruchomieniu aplikacji
            //InitializeComponent();
            //telefon = (Telefon)Telefon.OdczytajXML("plik");
            //if (telefon is object)
            //{
            //    //.ItemsSource = new ObservableCollection<Telefon>();  // tu musi byc chyba lista teleofnoów 
            //    //txtBox_Nazwa.Text = zespol.Nazwa;
            //    //txtBox_Kierownik.Text = zespol.Kierownik.ToString();
            //}
        }

        private void MetodaOdKrzyska(object sender, RoutedEventArgs e)
        {
            //ten kod wykonuje sie po kliknieciu
          //  Telefon t1 = new Telefon();
            KontoUzytkownika k1 = new KontoUzytkownika(
                "Carlos", 
                "Cucinni",
                "ptaki lataja kluczem",
                "karol.kucinski69@o2.pl");

            DebugLabelOdKrzyska.Content = k1.ToString(); 
        }

        private void button_Kategorie_click(object sender, RoutedEventArgs e)
        {
            OknoKategoria okk = new OknoKategoria();
            okk.Show();
        }

        private void button_Koszyk_clic(object sender, RoutedEventArgs e)
        {
            OknoKoszyk okn = new OknoKoszyk();
            okn.Show();
        }

        private void button_logowanie_clic(object sender, RoutedEventArgs e)
        {
            OknoLogowanie okl = new OknoLogowanie();
            okl.Show();
        }

        private void button_strona_glowna_clic(object sender, RoutedEventArgs e)
        {
            StronaGlowna strgl = new StronaGlowna();
            strgl.Show();
        }
    }
}
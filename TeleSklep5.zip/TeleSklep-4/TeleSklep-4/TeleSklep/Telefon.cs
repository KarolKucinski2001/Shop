﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace TeleSklep
{
    public enum EnumStan { nowy, uzywany }

    public enum EnumMarka { Samsung, Huawei, Xiaomi, Apple, LG };
    public enum EnumPamiecRam { dwa, cztery, osiem }


    //3 kalsy telefon stacjonarny zwykły i komorkowy, 
    //telfon zwykły abstract 
    //stel stajnoarany i komorkowy dzieduczy po zwykłym 

    //to powinno sie nazywac TelefonKomorkowy - obiekt tej klasy to jeden telefon, liczba mnoga to nazwa dla np listy takich telefonów
    public abstract class Telefon
    {
        static int identyfikator;
        string sygnatura;
        string modelTelefonu;
        double cena;
        EnumStan stan;
        string kolor;
        decimal waga;
        EnumMarka markaTelefonu;
        int pojemnoscBaterii;
        EnumPamiecRam pamiecRam;

        List<Telefon> wszystkieTelefony;





        public static int Identyfikator { get => identyfikator; set => identyfikator = value; }
        public string ModelTelefonu { get => modelTelefonu; set => modelTelefonu = value; }
        public EnumStan Stan { get => stan; set => stan = value; }
        public string Kolor { get => kolor; set => kolor = value; }
        public decimal Waga { get => waga; set => waga = value; }

        public int PojemnoscBaterii { get => pojemnoscBaterii; set => pojemnoscBaterii = value; }
        public double Cena
        {
            get => cena;
            set
            {
                if (value <= 0)
                {
                    throw new BlednaCenaException();
                }
                cena = value;
            }
        }






        public string Sygnatura { get => sygnatura; set => sygnatura = value; }
        public EnumMarka MarkaTelefonu { get => markaTelefonu; set => markaTelefonu = value; }
        public EnumPamiecRam PamiecRam { get => pamiecRam; set => pamiecRam = value; }

        // public List<Telefon> WszystkieTelefony { get => wszystkieTelefony; set => wszystkieTelefony = value; }

        static Telefon()
        {
            identyfikator = 0;

        }

        public Telefon()
        {
            // wszystkieTelefony = new List<Telefon>();
        }

        public Telefon(string modelTelefonu, EnumStan stan, string kolor, decimal waga, int pojemnoscBaterii, double cena
             , EnumMarka markaTelefonu, EnumPamiecRam pamiecRam) : this()
        {
            NadajSygnature();
            this.PamiecRam = pamiecRam;
            this.markaTelefonu = markaTelefonu;

            this.Stan = stan;
            this.Kolor = kolor;
            this.Waga = waga;

            this.PojemnoscBaterii = pojemnoscBaterii;
            this.Cena = cena;

        }

        public virtual void NadajSygnature()
        {
            Sygnatura = $"{identyfikator++: 000000}";
        }

        public override string ToString()
        {
            return $"Syg:{Sygnatura}, Marka {markaTelefonu}, modelTelefonu: {modelTelefonu}, Stan: {Stan}, Kolor: {Kolor}, Waga: {waga}, Pojemność baterii: {pojemnoscBaterii}, Cena: {cena}, Pamięć: {PamiecRam}";
        }

        public static void ZapiszXML(string nazwa, Telefon z)
        {
            XmlSerializer sr = new XmlSerializer(typeof(Telefon));
            using (StreamWriter sw = new StreamWriter($"{nazwa}.xml"))
            {
                sr.Serialize(sw, z);
            }
        }

        public static Telefon OdczytajXML(string nazwa)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Telefon));
            Telefon klasa;
            using (StreamReader reader = new StreamReader($"{nazwa}.xml"))
            {
                klasa = (Telefon)serializer.Deserialize(reader);
            }
            return klasa;
        }





    }
}


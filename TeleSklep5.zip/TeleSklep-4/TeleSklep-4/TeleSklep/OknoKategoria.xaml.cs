﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TeleSklep
{
    /// <summary>
    /// Logika interakcji dla klasy OknoKategoria.xaml
    /// </summary>
    public partial class OknoKategoria : Window
    {
        private List<Telefon> listaTelefonow;
        
        public OknoKategoria()
        {
            InitializeComponent();
            TelefonKomorkowy tk6 = new TelefonKomorkowy(5, "ios", 13, EnumLadowanieBezp.Tak, "z6", EnumStan.nowy, "czarny", 0.5m, 20, 100, EnumMarka.Apple, EnumPamiecRam.dwa);
            TelefonStacjonarny ts1 = new TelefonStacjonarny(EnumObslugaSMS.Nie, EnumGlosnoMowiacy.Tak, "x10", EnumStan.nowy, "biały", 1m, 10, 199, EnumMarka.Apple, EnumPamiecRam.cztery);
            listaTelefonow = new List<Telefon>();
            
            listaTelefonow.Add(tk6);
            listaTelefonow.Add(ts1);
            
            lstTelefons.ItemsSource = new ObservableCollection<Telefon>(listaTelefonow);
        }
        
        private void  Filtruj()
        {
            //do metody filtruj wysyłamy nowa liste, rbimy kopie listy telefonów która mamy
            List<Telefon> wszystkieTelefony = new List<Telefon>(listaTelefonow);
            
            // --------- przygotowujemy dane ----------------
            
            // dla ceny:
            int? cena = null;
            if(FiltrujCena.Text.Length > 0)
            {
                cena = Int32.Parse(FiltrujCena.Text);
            }

            //dla GB:
            // ... TODO
            EnumPamiecRam? pamiecRamuU;
            try
            {
                pamiecRamuU = (EnumPamiecRam)Enum.Parse(typeof(EnumPamiecRam), FiltrujGB.Text);
            }
            catch( ArgumentException exception)
            {
                Debug.WriteLine("Nie udalo sie sparsowac");
               pamiecRamuU = null;
            }
          //  Flowers Flower = (Flowers)Enum.Parse(typeof(Flowers), stringvalue);
            //if (FiltrujGB.Text)
            // {
            // pamiec
            // }

            // todo ...

            // --------- wykorzystujemy przygotowane dane do filtrowania----------------

            if (cena != null)
            {
                Debug.WriteLine($"Filtruje po cenie: {cena}");
                FiltrCena filtrCena = new FiltrCena((int) cena); // rzutowanie z nullowalnego inta na nie-nullowalny
                wszystkieTelefony = filtrCena.Filtruj(wszystkieTelefony);
            }

            if (!(pamiecRamuU is null))
            {
                Debug.WriteLine($"Filtruje po GB: {pamiecRamuU}");
                FlitrGB filtrGb = new FlitrGB((EnumPamiecRam)pamiecRamuU);
                wszystkieTelefony = filtrGb.Filtruj(wszystkieTelefony);
               // filtrGb.Filtruj(wszystkieTelefony);
            }

            // --------- wypisujemy dane na ekran przez to costam ----------------
            lstTelefons.ItemsSource = new ObservableCollection<Telefon>(wszystkieTelefony);
        }

        private void Szukaj_Click(object sender, RoutedEventArgs e)
        {
            if(sender != null)
            {
                //Filtruj(List < Telefon > listaWejsciowa);
            }
        }

        private void FiltrujGB_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Filtruj();
        }

        private void FiltrujCena_TextChanged(object sender, TextChangedEventArgs e)
        {
            Filtruj();
        }

        //ok atrybut, odsyła do metody 
        //gb.content -. stirng 
        //input pusty string to wtedy jaknie jest równy " " to if...
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleSklep
{
    class BlednaCenaException:Exception
    { 
        public BlednaCenaException() :base() { }      
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleSklep
{

    public class KontoUzytkownika
    {
        string imie;
        string nazwisko;
        string hasło;
        string email;

        public string Imie { get => imie; set => imie = value; }
        public string Nazwisko { get => nazwisko; set => nazwisko = value; }
        public string Hasło { get => hasło; set => hasło = value; }
        public string Email { get => email; set => email = value; }

        public KontoUzytkownika() : base()
        {

        }

        public KontoUzytkownika(string imie, string nazwisko, string hasło, string email)
        {
            this.imie = imie;
            this.nazwisko = nazwisko;
            this.hasło = hasło;
            this.email = email;
        }

        public override string ToString()
        {
            return $"Imie:{Imie} Nazwisko: {Nazwisko}  e-mail:{Email}";
        }



    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleSklep
{
    public class Koszyk:IKoszyk
    {
        private string klient;
        List<Telefon> listaTelefonow;

        public string Klient { get => klient; set => klient = value; }
        internal List<Telefon> ListaTelefonow { get => listaTelefonow; set => listaTelefonow = value; }

        public Koszyk()
        {
            this.ListaTelefonow = new List<Telefon>();
        }
        public Koszyk(string klient) : this()
        {
            this.klient = klient;
        }
        public Koszyk(string klient, List<Telefon> listaTelefonow) : this(klient)
        {
            this.listaTelefonow = listaTelefonow;
        }

        public void DodajProdukt(Telefon p)
        {
            listaTelefonow.Add(p);
        }

        public void UsunProdukt(string sygnatura)
        {
            for (int i = 0; i < listaTelefonow.Count; i++)
            {
                if (listaTelefonow[i].Sygnatura == sygnatura)
                {
                    listaTelefonow.RemoveAt(i);
                }

            }
        }
        public double WartoscKoszyka()
        {
            double suma = 0;
            foreach (Telefon p in listaTelefonow)
            {
                suma += p.Cena;
            }
            return suma;
        }

        public void UsunWszystkich()
        {
            listaTelefonow.Clear();
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"klient: {klient}").Append(Environment.NewLine);
            foreach (Telefon p in listaTelefonow)
            {
                sb.Append(Environment.NewLine).Append(p).Append(Environment.NewLine);

            }
            return sb.ToString();
        }

    }
}
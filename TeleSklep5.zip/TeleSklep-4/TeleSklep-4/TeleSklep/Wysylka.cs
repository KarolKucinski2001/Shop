﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleSklep
{

    public enum EnumWysylka { paczkomat, kurierPolecony, kurier, odbiorOsobisty }
    public class Wysylka 
    {
        
        EnumWysylka rodzajWysylki;

       
        public EnumWysylka RodzajWysylki { get => rodzajWysylki; set => rodzajWysylki = value; }

        public Wysylka() : base()
        {

        }

        public Wysylka( EnumWysylka rodzajWysylki)
        {
            
            this.RodzajWysylki = rodzajWysylki;
        }


        public double KosztWysylki()
        {
            double dodatek = 0;
            switch (RodzajWysylki)
            {
                case EnumWysylka.paczkomat:
                    dodatek = 8;
                    break;
                case EnumWysylka.odbiorOsobisty:
                    dodatek = 0;
                    break;
                case EnumWysylka.kurierPolecony:
                    dodatek = 10;
                    break;
                case EnumWysylka.kurier:
                    dodatek = 5;
                    break;
            }
            return dodatek;

        }
    }
}









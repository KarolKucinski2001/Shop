﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleSklep
{
 
    class FlitrGB : IFunkcjeFiltrujace
    {
        private EnumPamiecRam pamiecRamU;

        public FlitrGB(EnumPamiecRam pamiecRamU)
        {
            this.pamiecRamU = pamiecRamU;
        }

        public EnumPamiecRam PamiecRamU { get => pamiecRamU; set => pamiecRamU = value; }


        public List<Telefon> Filtruj(List<Telefon> listaWejsciowa)
        {
            List<Telefon> wynik = new List<Telefon>();  //chciemy stworzyc nowa pusta lite, do ktorej dodajemy
            foreach (Telefon t in listaWejsciowa)
            {
                if (t.PamiecRam == PamiecRamU) // jezeli jest rowna zadanej, to dodaj
                {
                    wynik.Add(t); 
                }
            }
            return wynik;
        }


    }
}

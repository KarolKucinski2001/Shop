﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeleSklep
{
    interface IFunkcjeFiltrujace
    {
        List<Telefon> Filtruj(List<Telefon> telefons);//nie ma znaczenia jaka nazwa
        

    }
}
